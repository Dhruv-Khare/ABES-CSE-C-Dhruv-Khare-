import React from 'react'

function Header() {
  return (
    <div style={{textAlign: 'center', margin: '20px'}}>
        <h1>Welcome to Our Hotels</h1>
    </div>
  )
}

export default Header