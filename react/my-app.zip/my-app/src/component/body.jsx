import React from 'react'

function body() {
  return (
    <div>
        <h3>Our Menu</h3>
    </div>
  )
}

export default body