import React from 'react'

function Footer() {
  return (
    <div style={{ backgroundColor: '#2458a7ff', padding: '10px' }}>
        <h3 style={{textAlign: 'center', margin: '20px'}}>ABES Engineering College, Ghaziabad</h3>
    </div>
  )
}

export default Footer